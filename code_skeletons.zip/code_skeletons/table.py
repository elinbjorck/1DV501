# A binary search based dictionary imlementation 
# only using list of length 4.

# Each node is a list of length four where positions
# 0 = key, 1 = value, 2 = left-child, 3 = right-child


# Creates and returns the root to a new empty table.
# The complete function is given and should not be changed.
def new_empty_root():
    return [None,None,None,None]

# Add a new key-value pair to table if the key doean't already exist.
# Update value if already key exists in the table.
def add(root,key,value):
    pass

# Returns a string representation of the table content.
# That is, all key-value pairs
def to_string(node):
    pass

# Returns the value for the given key. Returns None if key doesn't exists.
def get(node,key):
    pass

# Returns the maximum depth (an integer) of the tree.
# That is, the length of longest root-to-leaf path.
def max_depth(node):
    pass

# Returns the number og key-value pairs currently stored in the table
def count(node):
    pass

# Returns a list of all key-value pairs as tuples 
# sorted as left-to-right, in-order
def get_all_pairs(root):
    pass


